import { Box, Typography } from '@mui/material';

export default function Home() {
  return (
    <Box>
      <Typography>Next.js Skeleton with MUI</Typography>
    </Box>
  );
}
